import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Database } from "@/integrations/supabase/types";
import type { AppRole } from "./roles";
import { canAssignRole, canDeleteUser, canEditProfile, canManageUsers } from "./authz";

type DatabaseAppRole = Database["public"]["Enums"]["app_role"];

/**
 * Adds a new team member with profile, directory entry, and roles.
 * Creates an auth user (or links an existing one) using supabaseAdmin to bypass RLS.
 */
export const addTeamMember = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data) =>
    z
      .object({
        fullName: z.string().min(1),
        email: z.string().optional().or(z.literal("")),
        phone: z.string().optional().or(z.literal("")),
        carrier: z.string().optional().or(z.literal("")),
        roles: z.array(z.string()).default(["operator"]),
      })
      .parse(data),
  )
  .handler(async ({ data, context }) => {
    const { getCallerRoles, getCallerCompanyIds } = await import("./authz.server");
    const callerRoles = await getCallerRoles(context.supabase, context.userId);
    if (!canManageUsers(callerRoles)) {
      throw new Error("Only admins or managers can add team members.");
    }
    for (const role of data.roles) {
      if (!canAssignRole(callerRoles, role, "new-member", context.userId)) {
        throw new Error(`You are not allowed to assign the ${role} role.`);
      }
    }
    const companyIds = await getCallerCompanyIds(context.supabase, context.userId);
    const companyId = companyIds[0];
    if (!companyId) throw new Error("You are not a member of a company workspace.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    let memberId: string = crypto.randomUUID();
    const trimmedEmail = data.email?.trim() || null;
    const trimmedName = data.fullName.trim();
    const trimmedPhone = data.phone?.trim() || null;
    const carrier = data.carrier && data.carrier !== "none" ? data.carrier : null;

    if (trimmedEmail) {
      // Check if user profile already exists with this email
      const { data: existingProfiles } = await supabaseAdmin
        .from("profiles")
        .select("id")
        .eq("email", trimmedEmail)
        .limit(1);

      const existingId = existingProfiles?.[0]?.id;
      if (existingId) {
        memberId = existingId;
      } else {
        // Create an auth user via Admin API
        try {
          const { data: authUser, error: authError } = await supabaseAdmin.auth.admin.createUser({
            email: trimmedEmail,
            email_confirm: true,
            user_metadata: { full_name: trimmedName },
          });
          if (authUser?.user?.id) {
            memberId = authUser.user.id;
          } else if (authError) {
            console.warn("Auth user creation message:", authError.message);
          }
        } catch (e) {
          console.warn("Auth admin createUser fallback:", e);
        }
      }
    } else {
      // Create shadow auth user so foreign keys to auth.users succeed
      try {
        const shadowEmail = `crew_${memberId.slice(0, 8)}@plant.local`;
        const { data: authUser } = await supabaseAdmin.auth.admin.createUser({
          email: shadowEmail,
          email_confirm: true,
          user_metadata: { full_name: trimmedName },
        });
        if (authUser?.user?.id) {
          memberId = authUser.user.id;
        }
      } catch (e) {
        console.warn("Shadow auth user fallback:", e);
      }
    }

    // 0. Put them in the caller's company workspace.
    const { error: memberError } = await supabaseAdmin
      .from("company_members")
      .upsert({ company_id: companyId, user_id: memberId }, { onConflict: "company_id,user_id" });
    if (memberError) throw new Error(`Could not add to your workspace: ${memberError.message}`);

    // 1. Upsert profile
    const { error: profError } = await supabaseAdmin.from("profiles").upsert({
      id: memberId,
      full_name: trimmedName,
      email: trimmedEmail,
      phone: trimmedPhone,
      carrier: carrier,
      notify_email: Boolean(trimmedEmail),
      notify_sms: Boolean(trimmedPhone),
    });
    if (profError) {
      console.warn("Profile upsert warning:", profError.message);
    }

    // 2. Upsert team_directory
    const { error: dirError } = await supabaseAdmin.from("team_directory").upsert({
      id: memberId,
      full_name: trimmedName,
      updated_at: new Date().toISOString(),
    });
    if (dirError) {
      console.warn("Directory upsert warning:", dirError.message);
    }

    // 3. Insert roles
    if (data.roles && data.roles.length > 0) {
      const roleRows = data.roles.map((r) => ({
        user_id: memberId,
        role: r as DatabaseAppRole,
      }));
      const { error: roleError } = await supabaseAdmin
        .from("user_roles")
        .upsert(roleRows, { onConflict: "user_id,role" });
      if (roleError) {
        console.warn("Role insert warning:", roleError.message);
      } else if (!data.roles.includes("viewer")) {
        // New accounts start as read-only "viewer"; drop that default once a real role is assigned.
        await supabaseAdmin
          .from("user_roles")
          .delete()
          .eq("user_id", memberId)
          .eq("role", "viewer");
      }
    }

    return {
      id: memberId,
      full_name: trimmedName,
      email: trimmedEmail,
      phone: trimmedPhone,
      carrier: carrier,
    };
  });

/**
 * Updates a team member's name, email, phone, and carrier.
 */
export const updateTeamMember = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data) =>
    z
      .object({
        userId: z.string().uuid(),
        fullName: z.string().min(1),
        email: z.string().optional().nullable(),
        phone: z.string().optional().nullable(),
        carrier: z.string().optional().nullable(),
      })
      .parse(data),
  )
  .handler(async ({ data, context }) => {
    const { getCallerRoles, assertSharesCompany } = await import("./authz.server");
    const callerRoles = await getCallerRoles(context.supabase, context.userId);
    if (!canEditProfile(callerRoles, data.userId, context.userId)) {
      throw new Error("Only admins or managers can edit other people's details.");
    }
    await assertSharesCompany(context.supabase, data.userId);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const trimmedName = data.fullName.trim();
    const trimmedEmail = data.email?.trim() || null;
    const trimmedPhone = data.phone?.trim() || null;
    const carrier = data.carrier && data.carrier !== "none" ? data.carrier : null;

    // Update team directory
    await supabaseAdmin
      .from("team_directory")
      .upsert({ id: data.userId, full_name: trimmedName, updated_at: new Date().toISOString() });

    // Update profile
    await supabaseAdmin.from("profiles").upsert({
      id: data.userId,
      full_name: trimmedName,
      email: trimmedEmail,
      phone: trimmedPhone,
      carrier: carrier,
      notify_email: Boolean(trimmedEmail),
      notify_sms: Boolean(trimmedPhone),
    });

    return { ok: true };
  });

/**
 * Adds an assigned role to a member.
 */
export const addMemberRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data) =>
    z
      .object({
        userId: z.string().uuid(),
        role: z.string(),
      })
      .parse(data),
  )
  .handler(async ({ data, context }) => {
    const { getCallerRoles, assertSharesCompany } = await import("./authz.server");
    const callerRoles = await getCallerRoles(context.supabase, context.userId);
    if (!canAssignRole(callerRoles, data.role, data.userId, context.userId)) {
      throw new Error("You are not allowed to assign that role.");
    }
    await assertSharesCompany(context.supabase, data.userId);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("user_roles")
      .upsert(
        { user_id: data.userId, role: data.role as DatabaseAppRole },
        { onConflict: "user_id,role" },
      );
    if (error) throw error;
    return { ok: true };
  });

/**
 * Removes an assigned role from a member.
 */
export const removeMemberRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data) =>
    z
      .object({
        rowId: z.string().optional(),
        userId: z.string().uuid().optional(),
        role: z.string().optional(),
      })
      .parse(data),
  )
  .handler(async ({ data, context }) => {
    const { getCallerRoles, assertSharesCompany } = await import("./authz.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const callerRoles = await getCallerRoles(context.supabase, context.userId);

    // Resolve which user + role this request touches, then authorize that.
    let targetUserId = data.userId;
    let targetRole = data.role;
    if (data.rowId) {
      const { data: row, error } = await supabaseAdmin
        .from("user_roles")
        .select("user_id, role")
        .eq("id", data.rowId)
        .maybeSingle();
      if (error) throw error;
      if (!row) return { ok: true };
      targetUserId = row.user_id;
      targetRole = row.role;
    }
    if (!targetUserId || !targetRole) throw new Error("Specify which role to remove.");
    if (!canAssignRole(callerRoles, targetRole, targetUserId, context.userId)) {
      throw new Error("You are not allowed to remove that role.");
    }
    await assertSharesCompany(context.supabase, targetUserId);

    const { error } = await supabaseAdmin
      .from("user_roles")
      .delete()
      .eq("user_id", targetUserId)
      .eq("role", targetRole as DatabaseAppRole);
    if (error) throw error;
    return { ok: true };
  });

/**
 * Fetches the complete team roster with directory info, profiles, and roles.
 */
export const getTeamRoster = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { getCallerCompanyIds } = await import("./authz.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Only people who share a company workspace with the caller.
    const companyIds = await getCallerCompanyIds(context.supabase, context.userId);
    if (companyIds.length === 0) return [];
    const { data: memberRows, error: memberErr } = await supabaseAdmin
      .from("company_members")
      .select("user_id")
      .in("company_id", companyIds);
    if (memberErr) throw memberErr;
    const ids = Array.from(new Set((memberRows ?? []).map((m) => m.user_id)));
    if (ids.length === 0) return [];

    const [{ data: directory, error: dirErr }, { data: profiles }, { data: roles }] =
      await Promise.all([
        supabaseAdmin
          .from("team_directory")
          .select("id, full_name, updated_at")
          .in("id", ids)
          .order("full_name"),
        supabaseAdmin.from("profiles").select("id, full_name, email, phone, carrier").in("id", ids),
        supabaseAdmin.from("user_roles").select("id, user_id, role").in("user_id", ids),
      ]);

    if (dirErr) throw dirErr;

    const profMap = new Map((profiles ?? []).map((p) => [p.id, p]));

    return (directory ?? []).map((person) => {
      const p = profMap.get(person.id);
      return {
        id: person.id,
        full_name: person.full_name,
        email: p?.email ?? null,
        phone: p?.phone ?? null,
        carrier: p?.carrier ?? null,
        roles: (roles ?? [])
          .filter((r) => r.user_id === person.id)
          .map((r) => ({ id: r.id, role: r.role as AppRole })),
      };
    });
  });

/**
 * Fully removes a teammate: unassigns their work, drops roles/profile/directory
 * rows, and deletes the underlying account so they can no longer sign in.
 * Only admins and managers may call it (managers cannot remove senior staff), the
 * person must be in the caller's company workspace, and nobody can delete themselves.
 */
export const deleteTeamMember = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data) => z.object({ userId: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => {
    if (data.userId === context.userId) {
      throw new Error("You cannot delete your own account.");
    }

    const { getCallerRoles, assertSharesCompany } = await import("./authz.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    await assertSharesCompany(context.supabase, data.userId);
    const callerRoles = await getCallerRoles(context.supabase, context.userId);
    const { data: targetRoleRows } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", data.userId);
    const targetRoles = (targetRoleRows ?? []).map((r) => r.role as AppRole);

    if (!canDeleteUser(callerRoles, targetRoles, data.userId, context.userId)) {
      throw new Error("You are not allowed to delete this user.");
    }

    await supabaseAdmin
      .from("pm_schedules")
      .update({ assigned_to: null, assigned_label: null })
      .eq("assigned_to", data.userId);
    await supabaseAdmin
      .from("work_orders")
      .update({ assigned_to: null })
      .eq("assigned_to", data.userId);
    await supabaseAdmin.from("user_roles").delete().eq("user_id", data.userId);
    await supabaseAdmin.from("team_directory").delete().eq("id", data.userId);
    await supabaseAdmin.from("profiles").delete().eq("id", data.userId);

    try {
      const { error: authError } = await supabaseAdmin.auth.admin.deleteUser(data.userId);
      if (authError && !/not found/i.test(authError.message)) {
        console.warn("Auth delete user info:", authError.message);
      }
    } catch (e) {
      console.warn("Auth delete exception:", e);
    }

    return { ok: true };
  });
