import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { fetchAllRows } from "@/lib/paged";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { WorkOrderDialog } from "@/components/work-order-dialog";
import { EditPmScheduleDialog } from "@/components/edit-pm-schedule-dialog";
import { PmCompleteDialog, isoDay } from "@/components/pm-complete-dialog";
import { daysUntil, prettyLabel, seasonLabel } from "@/lib/cmms";
import { toast } from "sonner";
import {
  AlertTriangle,
  CalendarClock,
  CheckCircle2,
  RefreshCw,
  Printer,
  ClipboardPlus,
} from "lucide-react";
import {
  openMorningPrintDialog,
  getAutoPrintConfig,
  formatTime12h,
} from "@/lib/auto-morning-print";

export const Route = createFileRoute("/_authenticated/pm-due")({
  head: () => ({
    meta: [
      { title: "PMs Due & Overdue | AssetCareConnect" },
      {
        name: "description",
        content:
          "Daily list of preventive maintenance tasks that are overdue, due today, or due this week.",
      },
      { property: "og:title", content: "PMs Due & Overdue" },
      {
        property: "og:description",
        content: "Today's preventive maintenance worklist, refreshed automatically every day.",
      },
    ],
  }),
  component: PmDuePage,
});

function PmDuePage() {
  const queryClient = useQueryClient();
  const [day, setDay] = useState(() => isoDay(new Date()));
  const [config, setConfig] = useState(getAutoPrintConfig);

  useEffect(() => {
    const handleConfigChange = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail) setConfig(customEvent.detail);
    };
    window.addEventListener("auto-morning-print-config-changed", handleConfigChange);
    return () =>
      window.removeEventListener("auto-morning-print-config-changed", handleConfigChange);
  }, []);

  // Roll the worklist over automatically at midnight (and whenever the tab
  // regains focus on a new calendar day).
  useEffect(() => {
    const tick = () => {
      const current = isoDay(new Date());
      setDay((prev) => (prev === current ? prev : current));
    };
    const interval = window.setInterval(tick, 60_000);
    window.addEventListener("focus", tick);
    document.addEventListener("visibilitychange", tick);
    return () => {
      window.clearInterval(interval);
      window.removeEventListener("focus", tick);
      document.removeEventListener("visibilitychange", tick);
    };
  }, []);

  const horizon = isoDay(new Date(new Date(day + "T00:00:00").getTime() + 7 * 86400000));

  const pms = useQuery({
    queryKey: ["pms", "due", day],
    refetchOnWindowFocus: true,
    queryFn: async () => {
      return fetchAllRows((from, to) =>
        supabase
          .from("pm_schedules")
          .select(
            "*, assets(id, name, location_name, building, tag_number, class, manufacturer, model)",
          )
          .eq("active", true)
          .lte("next_due", horizon)
          .order("next_due")
          .order("id")
          .range(from, to),
      );
    },
  });

  const generate = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase.rpc("generate_due_pm_work_orders", {
        _horizon_days: 7,
      });
      if (error) throw error;
      return data ?? 0;
    },
    onSuccess: (n) => {
      toast.success(
        n > 0
          ? `Created ${n} work order${n === 1 ? "" : "s"} for due PMs`
          : "Every due PM already has an open work order",
      );
      queryClient.invalidateQueries({ queryKey: ["work-orders"] });
      queryClient.invalidateQueries({ queryKey: ["dashboard"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  type Row = NonNullable<typeof pms.data>[number];
  const rows = pms.data ?? [];
  const overdue = rows.filter((p) => p.next_due < day);
  const dueToday = rows.filter((p) => p.next_due === day);
  const dueSoon = rows.filter((p) => p.next_due > day);

  const renderRow = (pm: Row) => {
    const d = daysUntil(pm.next_due);
    return (
      <div key={pm.id} className="flex flex-wrap items-center gap-3 p-3">
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium">{pm.title}</p>
          <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground">
            {pm.assets ? (
              <Link
                to="/assets/$assetId"
                params={{ assetId: pm.assets.id }}
                className="font-medium text-foreground hover:underline"
              >
                {pm.assets.name}
              </Link>
            ) : (
              <span className="italic">Unassigned equipment asset</span>
            )}
            <span>·</span>
            <span>every {pm.interval_days} days</span>
            <span>·</span>
            <span>{prettyLabel(pm.priority)}</span>
            {pm.last_completed && <span>· last done {pm.last_completed}</span>}
          </div>
          {pm.tasks && <p className="mt-1 text-xs text-muted-foreground">{pm.tasks}</p>}
        </div>
        {seasonLabel(pm.season_start_md, pm.season_end_md) && (
          <Badge variant="outline" className="border-primary/40 text-primary">
            Seasonal · {seasonLabel(pm.season_start_md, pm.season_end_md)}
          </Badge>
        )}
        <Badge
          variant={d !== null && d < 0 ? "destructive" : "secondary"}
          className="font-mono"
          title={pm.next_due}
        >
          {d === null
            ? pm.next_due
            : d < 0
              ? `${Math.abs(d)}d overdue`
              : d === 0
                ? "Due today"
                : `in ${d}d`}
        </Badge>
        <EditPmScheduleDialog pm={pm} />
        <WorkOrderDialog
          assetId={pm.asset_id}
          pmScheduleId={pm.id}
          defaultTitle={pm.title}
          lockAsset
          trigger={
            <Button size="sm" variant="outline">
              Issue WO
            </Button>
          }
        />
        <PmCompleteDialog
          pm={pm}
          completedOn={day}
          trigger={
            <Button size="sm" variant="ghost">
              <CheckCircle2 className="size-4" /> Complete
            </Button>
          }
        />
      </div>
    );
  };

  const section = (
    title: string,
    icon: typeof AlertTriangle,
    list: Row[],
    tone: "danger" | "warn" | "muted",
  ) => {
    const Icon = icon;
    return (
      <section className="panel overflow-hidden">
        <div className="flex items-center justify-between gap-2 border-b border-border px-4 py-2.5">
          <h2 className="flex items-center gap-2 text-sm font-semibold uppercase tracking-wide">
            <Icon
              className={`size-4 ${tone === "danger" ? "text-destructive" : tone === "warn" ? "text-primary" : "text-muted-foreground"}`}
            />
            {title}
          </h2>
          <Badge variant={tone === "danger" ? "destructive" : "secondary"} className="font-mono">
            {list.length}
          </Badge>
        </div>
        {list.length === 0 ? (
          <p className="p-4 text-sm text-muted-foreground">Nothing here — all clear.</p>
        ) : (
          <div className="divide-y divide-border">{list.map(renderRow)}</div>
        )}
      </section>
    );
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="label-caps">Daily worklist · {day}</p>
          <h1 className="text-2xl font-bold">PMs due &amp; overdue</h1>
        </div>
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            onClick={() => openMorningPrintDialog()}
            className="gap-1.5 text-xs font-bold bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm"
            title="Batch print today's PMs and work orders"
          >
            <Printer className="size-3.5" /> Morning Print Dispatch
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => generate.mutate()}
            disabled={generate.isPending}
            className="gap-1.5 text-xs font-semibold"
            title="Create a work order for every due PM that doesn't have one yet"
          >
            <ClipboardPlus className="size-3.5" /> Generate work orders
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => pms.refetch()}
            disabled={pms.isFetching}
            className="gap-1.5 text-xs font-semibold"
          >
            <RefreshCw className={`size-3.5 ${pms.isFetching ? "animate-spin" : ""}`} /> Refresh
          </Button>
          <Link to="/pm-schedule">
            <Button variant="outline" size="sm" className="text-xs font-semibold">
              Full PM schedule
            </Button>
          </Link>
        </div>
      </div>

      {/* Auto-Print Schedule Status Banner */}
      <div className="rounded-lg border border-border bg-card p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs shadow-sm">
        <div className="flex items-center gap-2.5">
          <div className="flex size-7 items-center justify-center rounded-md bg-primary/10 text-primary shrink-0">
            <Printer className="size-3.5" />
          </div>
          <div>
            {config.enabled ? (
              <p className="text-foreground font-medium">
                Automatic morning printing is <span className="font-bold text-primary">active</span>
                . Daily shift packet set to print at{" "}
                <span className="font-mono font-bold text-foreground">
                  {formatTime12h(config.scheduledTime)}
                </span>
                .
              </p>
            ) : (
              <p className="text-muted-foreground">
                Automatic morning printing is currently <span className="italic">off</span>. Turn it
                on in settings to automatically print morning PMs and work orders at shift start.
              </p>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="h-7 text-xs"
            onClick={() => openMorningPrintDialog()}
          >
            Preview Daily Packet
          </Button>
          <Link to="/settings">
            <Button
              variant="ghost"
              size="sm"
              className="h-7 text-xs text-muted-foreground hover:text-foreground"
            >
              Configure Schedule
            </Button>
          </Link>
        </div>
      </div>

      {pms.isLoading ? (
        <p className="text-sm text-muted-foreground">Loading today's worklist…</p>
      ) : pms.error ? (
        <p className="text-sm text-destructive">{(pms.error as Error).message}</p>
      ) : (
        <div className="space-y-4">
          {section("Overdue", AlertTriangle, overdue, "danger")}
          {section("Due today", CalendarClock, dueToday, "warn")}
          {section("Due within 7 days", CalendarClock, dueSoon, "muted")}
        </div>
      )}
    </div>
  );
}
